//
//  THContactPickerTableViewCell.h
//  ContactPicker
//
//  Created by Mac on 3/27/14.
//  Copyright (c) 2014 Tristan Himmelman. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface THContactPickerTableViewCell : UITableViewCell

@end
