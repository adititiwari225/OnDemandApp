//
//  ForgotPasswordViewController.h
//  Customer
//
//  Created by Jamshed Ali on 12/08/16.
//  Copyright © 2016 Jamshed Ali. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ForgotPasswordViewController : UIViewController {
    
    IBOutlet UIWebView *webViewForgetPassword;
    
}

- (IBAction)backButtonClicked:(id)sender;

@end
