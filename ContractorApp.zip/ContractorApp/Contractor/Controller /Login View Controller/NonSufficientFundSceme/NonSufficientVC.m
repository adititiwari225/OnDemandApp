//
//  NonSufficientVC.m
//  Contractor
//
//  Created by Aditi on 09/02/17.
//  Copyright © 2017 Jamshed Ali. All rights reserved.
//

#import "NonSufficientVC.h"
#import "AppDelegate.h"

@interface NonSufficientVC ()
@property (weak,nonatomic) IBOutlet UITextView *pendingLabelText;

@end

@implementation NonSufficientVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    if (APPDELEGATE.hubConnection) {
        [APPDELEGATE.hubConnection  reconnecting];
    }
    
    [_pendingLabelText setText:self.nonSufficientMessage];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)tryAgainButtonMethodeAction:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)signOffButtonActionMethode:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

@end
