//
//  NonSufficientVC.h
//  Contractor
//
//  Created by Aditi on 09/02/17.
//  Copyright © 2017 Jamshed Ali. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NonSufficientVC : UIViewController
@property (strong, nonatomic) NSString *nonSufficientMessage;
@end
