//
//  CurrentLocationsViewController.m
//  Contractor
//
//  Created by Deepak on 9/1/16.
//  Copyright © 2016 Jamshed Ali. All rights reserved.
//

#import "CurrentLocationsViewController.h"
#import "OnDemandDatePushNotificationViewController.h"
#import "ServerRequest.h"
#import "AppDelegate.h"
#import "AlertView.h"

@interface CurrentLocationsViewController () {
    
    SingletonClass *sharedInstance;
}

@end

@implementation CurrentLocationsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationController.interactivePopGestureRecognizer.enabled = NO;
    
    sharedInstance = [SingletonClass sharedInstance];
    
}

- (void)viewWillAppear:(BOOL)animated {
    
    
    [super viewWillAppear:animated];
    if (APPDELEGATE.hubConnection) {
        [APPDELEGATE.hubConnection  reconnecting];
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(checkSignalRReqest:)
                                                 name:@"SignalR"
                                               object:nil];
    
    
}

- (void)checkSignalRReqest:(NSNotification*) noti {
    
    
    NSDictionary *responseObject = noti.userInfo;
    NSString *requestTypeStr = [NSString stringWithFormat:@"%@",[responseObject objectForKey:@"dateType"]];
    
    if ([requestTypeStr isEqualToString:@"1"]) {
        
        NSString *dateIdStr = [responseObject objectForKey:@"dateId"];
        
        NSDictionary *dataDictionary = @{@"DateID":dateIdStr,@"Type":requestTypeStr};
        if (sharedInstance.onDemandPushNotificationArray.count) {
            [sharedInstance.onDemandPushNotificationArray removeAllObjects];
        }
        [sharedInstance.onDemandPushNotificationArray addObject:dataDictionary];
        
        NSLog(@"sharedInstance.onDemandPushNotificationArray ==  %@",sharedInstance.onDemandPushNotificationArray);
        
        OnDemandDatePushNotificationViewController *dateDetailsView = [self.storyboard instantiateViewControllerWithIdentifier:@"onDamndDatePushNotification"];
        
        [self.navigationController pushViewController:dateDetailsView animated:YES];
        
    } else {
        
    }
}


- (void)viewWillDisappear:(BOOL)animated {
    
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:@"SignalR"
                                                  object:nil];
}


- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    return YES;
}

// It is important for you to hide the keyboard
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    
    [textField resignFirstResponder];
    return YES;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    NSLog(@"touchesBegan:withEvent:");
    [self.view endEditing:YES];
    [super touchesBegan:touches withEvent:event];
}

- (IBAction)doneButtonClicked:(id)sender {
    
    if([countryTextField.text length]==0) {
        
        UIAlertView *alrtShow=[[UIAlertView alloc] initWithTitle:@"Alert" message:@"Please enter the street address." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alrtShow show];
        
    } else if([cityTextField.text length]==0) {
        
        UIAlertView *alrtShow=[[UIAlertView alloc] initWithTitle:@"Alert" message:@"Please enter the city." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alrtShow show];
        
    } else if([stateTextField.text length]==0) {
        
        UIAlertView *alrtShow=[[UIAlertView alloc] initWithTitle:@"Alert" message:@"Please enter the state." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alrtShow show];
        
    } else if([zipCodeTextField.text length]==0) {
        
        UIAlertView *alrtShow=[[UIAlertView alloc] initWithTitle:@"Alert" message:@"Please enter the zipcode." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alrtShow show];
        
    } else  {
        [self.view endEditing:YES];
        [self callLatLongApiForString:countryTextField.text];
    }
    
}

-(void)callLatLongApiForString:(NSString *)locationString{
    
    [ProgressHUD show:@"Please wait..." Interaction:NO];
    if (![APPDELEGATE geocoder]) {
        
        APPDELEGATE.geocoder= [[CLGeocoder alloc] init];
    }
    
    [[APPDELEGATE geocoder] geocodeAddressString:locationString completionHandler:^(NSArray *placemarks, NSError *error) {
        if ([placemarks count] > 0) {
            
            CLPlacemark *placemark = [placemarks objectAtIndex:0];
            NSString *locatedAt = [[placemark.addressDictionary valueForKey:@"FormattedAddressLines"] componentsJoinedByString:@", "];
            
            NSString  *streetStr = [CommonUtils checkStringForNULL:placemark.thoroughfare];
            NSString  *cityStr = [CommonUtils checkStringForNULL:placemark.locality];
            NSString  *stateStr = [CommonUtils checkStringForNULL:placemark.administrativeArea];
            NSString  *countryStr = [CommonUtils checkStringForNULL:placemark.country];
            NSString  * zipCodeStr = [CommonUtils checkStringForNULL:placemark.postalCode];
            CLLocation *location = placemark.location;
            float latitude=  location.coordinate.latitude;
            float longitude= location.coordinate.longitude;
            NSLog(@"Location Value  %@,%@,%@,%@,%@,%@,%@",streetStr,locatedAt,streetStr,cityStr,stateStr,countryStr,zipCodeStr);
            NSLog(@"Latitutde Value %f, Logtitude VAlue%f",latitude,longitude);
            sharedInstance.customLatiValueStr = [NSString stringWithFormat:@"%.8f", location.coordinate.latitude];
            sharedInstance.customLongiValueStr = [NSString stringWithFormat:@"%.8f", location.coordinate.longitude];
            if ([sharedInstance.customLatiValueStr length]) {
                [self updatePreferencesLocationApiData];
            }
        }
    }];
    
}



#pragma mark-- PreferencesLocation API Call
-(void)updatePreferencesLocationApiData
{
    
    NSString *userIdStr = sharedInstance.userId;
    locationStr = [NSString stringWithFormat:@"%@,%@,%@,%@",cityTextField.text,stateTextField.text,countryTextField.text,zipCodeTextField.text];
    
    NSString *urlstr=[NSString stringWithFormat:@"%@?userID=%@&City=%@&State=%@&Country=%@&Zipcode=%@&StateAbbrevation=%@&Lat=%@&Long=%@",APIPrefernceChangeLocationData,userIdStr,cityTextField.text,stateTextField.text,countryTextField.text,zipCodeTextField.text,@"null",sharedInstance.customLatiValueStr,sharedInstance.customLongiValueStr];
    NSString *encodedUrl = [urlstr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    [ServerRequest AFNetworkPostRequestUrlForQA:encodedUrl withParams:nil CallBack:^(id responseObject, NSError *error) {
        NSLog(@"response object Get UserInfo List %@",responseObject);
        
        [ProgressHUD dismiss];
        if ([responseObject isKindOfClass:[NSNull class]] || (![responseObject isKindOfClass:[NSDictionary class]])) {
          //  [CommonUtils showAlertWithTitle:@"Sorry" withMsg:@"Could not connect to the server" inController:self];
            
        }
        else{
            if(!error){
                
                NSLog(@"Response is --%@",responseObject);
                
                if ([[responseObject objectForKey:@"StatusCode"] intValue] ==1) {
                    
                    [[AlertView sharedManager] presentAlertWithTitle:@"Location Status" message:[responseObject objectForKey:@"Message"]
                                                 andButtonsWithTitle:@[@"OK"] onController:self
                                                       dismissedWith:^(NSInteger index, NSString *buttonTitle)
                     {
                         if ([buttonTitle isEqualToString:@"OK"]) {
                             [self.view endEditing:YES];
                             [self.navigationController popViewControllerAnimated:YES];
                         }}];
                    
                }
                else
                {
                    [CommonUtils showAlertWithTitle:@"Alert" withMsg:[responseObject objectForKey:@"Message"] inController:self];
                }
            } else {
                
                NSLog(@"Error");
            }
        }
    }];
}


-(void)getStateAbbrevationWithString:(NSString *)stateName
{
    
    NSString *urlstr=[NSString stringWithFormat:@"http://gd.geobytes.com/AutoCompleteCity?callback=?&q=%@",stateName];
    NSString *encodedUrl = [urlstr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL *url = [NSURL URLWithString:encodedUrl];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [NSURLConnection sendAsynchronousRequest:request
                                       queue:[NSOperationQueue mainQueue]
                           completionHandler:^(NSURLResponse *response,
                                               NSData *data, NSError *connectionError)
     {
         // [ProgressHUD dismiss];
         if (data.length > 0 && connectionError == nil)
         {
             //  sharedInstance.customStateAbbriviation
             NSString *jsonString = [NSString stringWithUTF8String:[data bytes]];
             if (jsonString.length) {
                 NSString *jsonString1 =[jsonString substringFromIndex:2];
                 NSString *subString = [jsonString1 substringToIndex:[jsonString1 length]- 4];
                 NSLog(@"Response>>>%@",subString);
                 NSArray *arr = [subString componentsSeparatedByString:@","];
                 NSLog(@"Response>>>%lu",(unsigned long)arr.count);
                 sharedInstance.customStateAbbriviation = [arr objectAtIndex:1];
                 if (sharedInstance.customStateAbbriviation.length) {
                     [self updatePreferencesLocationApiData];
                 }
             }
          }
     }];
}

-(void)changeByteIntoCurrectFormateWith:(NSData *)dataValue{
    NSData *data = dataValue; // your image data
    const unsigned char *bytes = [data bytes]; // no need to copy the data
    NSUInteger length = [data length];
    NSMutableArray *byteArray = [NSMutableArray array];
    for (NSUInteger i = 0; i < length; i++) {
        [byteArray addObject:[NSNumber numberWithUnsignedChar:bytes[i]]];
    }
    NSDictionary *dictJson = [NSDictionary dictionaryWithObjectsAndKeys:
                              byteArray, @"photo",
                              nil];
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dictJson options:0 error:NULL];
    NSLog(@"Json Data %@",jsonData);
}

- (IBAction)backButtonClicked:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
