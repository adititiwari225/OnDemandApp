
//  LegalViewController.h
//  Customer
//  Created by Jamshed Ali on 15/06/16.
//  Copyright © 2016 Jamshed Ali. All rights reserved.



#import <UIKit/UIKit.h>

@interface LegalViewController : UIViewController
- (IBAction)backButtonClicked:(id)sender;
- (IBAction)termsButtonClicked:(id)sender;
- (IBAction)privacyPolicyButtonClicked:(id)sender;

@end
