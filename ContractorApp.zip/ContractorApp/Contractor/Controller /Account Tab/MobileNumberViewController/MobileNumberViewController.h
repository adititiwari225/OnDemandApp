//
//  MobileNumberViewController.h
//  Contractor
//
//  Created by Aditi on 21/12/16.
//  Copyright © 2016 Jamshed Ali. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MobileNumberViewController : UIViewController
@property (assign, nonatomic) BOOL isForMobilenumber;
@property (strong,  nonatomic) NSMutableArray *userInfoArr;
@end
